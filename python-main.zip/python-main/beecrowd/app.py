n1 = 100
n2 = 80 
n3 = 60 
n4 = 40

resultado = (n1 * 2 + n2 * 4 + n3 * 6 + n4 * 8) / 20 

print(resultado)